from fastapi import FastAPI
from routers import documents, search, qa

app = FastAPI(title="Search Document  API")

app.include_router(documents.router)
app.include_router(search.router)
app.include_router(qa.router)
