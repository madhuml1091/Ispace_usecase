from typing import Dict, Any, Optional
from pydantic import BaseModel

class Document(BaseModel):
    id: str
    text: str
    metadata: Optional[Dict[str, Any]] = None

class SearchQuery(BaseModel):
    query: str

class QARequest(BaseModel):
    question: str
    top_k: int = 3
