from fastapi import APIRouter, HTTPException
from models.schemas import Document
from services.elasticsearch_service import index_document

router = APIRouter()

@router.post("/documents")
def ingest_document(doc: Document):
    try:
        index_document(doc.id, doc.text, doc.metadata or {})
        return {"status": "success", "id": doc.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
