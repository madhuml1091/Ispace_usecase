from fastapi import APIRouter, HTTPException
from models.schemas import SearchQuery
from services.elasticsearch_service import search_documents

router = APIRouter()

@router.get("/search")
def search_documents_endpoint(query: str, top_k: int = 5):
    try:
        results = search_documents(query, top_k)
        return {"results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
