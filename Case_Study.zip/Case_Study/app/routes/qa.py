from fastapi import APIRouter, HTTPException
from models.schemas import QARequest
from services.elasticsearch_service import search_documents
from services.llm_service import answer_question

router = APIRouter()

@router.post("/qa")
def qa_endpoint(request: QARequest):
    try:
        docs = search_documents(request.question, request.top_k)
        if not docs:
            raise HTTPException(status_code=404, detail="No documents found")
        answer = answer_question(request.question, docs)
        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
