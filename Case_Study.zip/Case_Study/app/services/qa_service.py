from typing import List

def answer_question(question: str, documents: List[dict]) -> str:
    """
    Stub for LLM integration. Replace with OpenAI, HuggingFace, or LangChain pipeline.
    """
    context = " ".join([doc["text"] for doc in documents])
    # Example: call your LLM here
    return f"Answer to '{question}' based on context: {context[:200]}..."
