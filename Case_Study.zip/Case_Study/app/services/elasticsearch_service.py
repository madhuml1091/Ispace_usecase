from elasticsearch import Elasticsearch, NotFoundError

es = Elasticsearch("http://localhost:9200")

INDEX_NAME = "documents"

def index_document(doc_id: str, text: str, metadata: dict):
    try:
        es.index(index=INDEX_NAME, id=doc_id, document={"text": text, "metadata": metadata})
    except Exception as e:
        raise RuntimeError(f"Failed to index document: {e}")

def search_documents(query: str, top_k: int = 5):
    try:
        response = es.search(
            index=INDEX_NAME,
            query={"match": {"text": query}},
            size=top_k
        )
        return [hit["_source"] for hit in response["hits"]["hits"]]
    except NotFoundError:
        return []
    except Exception as e:
        raise RuntimeError(f"Search failed: {e}")
