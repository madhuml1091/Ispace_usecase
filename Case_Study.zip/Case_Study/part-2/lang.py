from langchain.chains import RetrievalQA
from langchain.llms import OpenAI
from langchain.vectorstores import ElasticVectorSearch

retriever = ElasticVectorSearch(es_url="http://localhost:9200", index_name="documents")
llm = OpenAI(model="gpt-5", temperature=0.2)

qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever.as_retriever(),
    chain_type="stuff",  # or "map_reduce"
    return_source_documents=True
)

def answer_question(question: str):
    try:
        result = qa_chain({"query": question})
        return {"answer": result["result"], "sources": result["source_documents"]}
    except Exception as e:
        return {"answer": f"Error: {str(e)}"}
