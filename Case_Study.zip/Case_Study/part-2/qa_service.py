import os
import openai
from typing import List, Dict

openai.api_key = os.getenv("OPENAI_API_KEY")

def build_prompt(question: str, documents: List[Dict]) -> str:
    context = "\n\n".join([f"Doc {i+1}: {doc['text']}" for i, doc in enumerate(documents)])
    prompt = f"""
You are a helpful assistant. Use the following documents to answer the question.

Context:
{context}

Question: {question}

Instructions:
- Provide a concise, factual answer.
- If unsure, say "I don't know based on the given documents."
- Cite relevant document snippets when possible.
"""
    return prompt

def answer_question(question: str, documents: List[Dict]):
    if not documents:
        return {"answer": "No relevant documents found."}

    prompt = build_prompt(question, documents)

    try:
        response = openai.ChatCompletion.create(
            model="gpt-5",  # or "gpt-3.5-turbo"
            messages=[{"role": "system", "content": "You are a RAG assistant."},
                      {"role": "user", "content": prompt}],
            temperature=0.2
        )
        answer = response["choices"][0]["message"]["content"]
        return {"answer": answer}
    except Exception as e:
        return {"answer": f"Error generating answer: {str(e)}"}
